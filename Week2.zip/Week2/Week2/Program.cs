﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Week2
{
	internal class Program
	{

// Task 2
		/** This is the Documentation comment for my main function
		* 
		*/

		// this is a single line comment

		/* this is a multi line
		* comment
		*/

		static void Main(string[] args)
		{
			// Task 1
			Console.WriteLine("// Task 1");
			Console.WriteLine("Hello, my name is Korbin");
			Console.WriteLine("My favorite color is red");

			// Task 3
			Console.WriteLine("// Task 3");
			string name = "Sarah";
			int population = 1500000;
			double temp = 23.5;
			bool isStudent = true;

			Console.WriteLine("The person's name is " + name);
			Console.WriteLine("The population is " + population);
			Console.WriteLine("The temperature is " + temp + " degreese Celsius");
			Console.WriteLine("Is the person a student? " + isStudent);

			// Task 4
			Console.WriteLine("// Task 4");
			double pi = 3.14159;
			Console.WriteLine("Enter the radius as a whole number:   ");
			int radius = int.Parse(Console.ReadLine());
			double area = pi * (radius * radius);

			Console.WriteLine("the area of a circle with a radius of " + radius + " is " + area);

			// Task 5
			Console.WriteLine("// Task 5");
			Console.WriteLine("Enter your name:   ");
			string name2 = Console.ReadLine();
			Console.WriteLine("Enter your age:   ");
			int age = int.Parse(Console.ReadLine());

			Console.WriteLine("Hello " + name2);
			if (age >= 18)
			{
				Console.WriteLine("You are eligible to vote because you are " + age);
			}
			else
			{
				Console.WriteLine("You are not eligible to vote because you are " + age);
			}

			// Task 6
			Console.WriteLine("// Task 6");
			Console.WriteLine("Enter a int:   ");
			int num1 = int.Parse(Console.ReadLine());
			Console.WriteLine("Enter a int:   ");
			int num2 = int.Parse(Console.ReadLine());
			Console.WriteLine("(1 = Addition)\n(2 = Subtraction)\n(3 = Multiplication)\n(4 = Division)\nEnter a number 1-4:");
			int choice = int.Parse(Console.ReadLine());
			string op = "";
			double calculation = 0;


			switch (choice)
			{
				case 1:
					op = "Addition";
					calculation = num1 + num2;
					break;
				case 2:
					op = "Subtraction";
					calculation = num1 - num2;
					break;
				case 3:
					op = "Multiplication";
					calculation = num1 * num2;
					break;
				case 4:
					op = "Division";
					calculation = num1 / num2;
					break;
				default: Console.WriteLine(choice + " is an invalid choice");
					break;
			}
			Console.WriteLine(op + " result = " + calculation);
		}
	}
}
